// Declaring 7 variable with movie names
var movie1 = "Interstellar";
var movie2 = "The Impossible";
var movie3 = "The Nun";
var movie4 = "Spider-Man";
var movie5 = "The Lord of Rings";
var movie6 = "Avatar";
var movie7 = "Titanic";

// Creating an array to hold 7 movie names
var movies = [movie1, movie2, movie3, movie4, movie5, movie6, movie7];

// Loop through array & output to the console
for (var i = 0; i < movies.length; i++) {
    console.log("Movie " + (i + 1) + ": " + movies[i]);
}

// Asking user for movie selection and their input
var userChoice;
while (true) {
    userChoice = prompt("Which top 7 movie would you like?", "Pick a number: 1-7");
    userChoice = parseInt(userChoice);
    
    if (userChoice >= 1 && userChoice <= 7) {
        alert("Number " + userChoice + " on the list is " + movies[userChoice - 1]);
        break;
    } else {
        alert("Please enter a number between 1 and 7!");
    }
}
