//LAB 3 - ARRAYS & LOOPS - PART 3

//PART 3 - SHOPPING CART SHIPPING
//==== VARIABLES ========
var shoppingcartitems = [];
var totalprice = 0;
var shippingthreshold = 35;
//==== LOGIC ========
//CHECK FOR ITEMS UNTIL THRESHOLD IS MET.
while (totalprice <= shippingthreshold){
	//GET ITEM COST FROM USER
	var itemprice = parseInt(prompt("Enter value of the item"));
	totalprice+= itemprice;
	shoppingcartitems.push(itemprice);
	if (totalprice >= shippingthreshold)
	
//SEND POPUP MESSAGE TO USER
{
	alert("Your shipping for this order will be free");
	break;
}
}
//SEND OUTPUT TO CONSOLE

var MESSAGE = "Item Price: " + shoppingcartitems.join("|");

console.log(MESSAGE);

alert("Your Total value of the purchase is "+ totalprice);
