// Part 1: Defining my Art Piece
var art = {
    title: "Starry Night",
    artist: "Vincent Van Gogh",
    year: 1889,
    medium: "Oil on Canvas",

 // Method for updating the medium of the artwork
updatemedium: function(){
    art.medium = newMedium;
    alert(`The Medium Updated to: ${art.medium}`);
    }
};

// Output Initial Object to Console
console.log(art);

// Part 2: User Interaction with the Object
// Prompt the user to enter a new title (pre-filled with the existing title as Starry Night)
var newTitle = prompt("Enter a new art piece title:", art.title);
art.title = newTitle;

// Prompt the user to enter a new artist (pre-filled with the existing artist as Vincent Van Gogh)
var newArtist = prompt("Enter a new artist:", art.artist);
art.artist = newArtist;

// // Prompt the user to enter a new medium (pre-filled with the existing medium as Oil on Canvas) & Call Object Method to Update Medium
var newMedium = prompt("Enter a new medium:", art.medium);
art.updatemedium(newMedium);

// Output Updated Object to Console
console.log("Updated Art Object:", art);

// Part 3: Stretch Goal - Show Default Values in Prompts
var newYear = prompt("Enter the year of creation:", art.year);
art.year = newYear;

// Displaying the updated object details in an alert
alert(`Art Piece Updated: 
    Title: ${art.title} 
    Artist: ${art.artist} 
    Year: ${art.year} 
    Medium: ${art.medium}`);

// Final Console Output
console.log("Final Art Object:",art);